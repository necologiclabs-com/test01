# シーケンス図

## 全体フロー（1 分間のサイクル）

```mermaid
sequenceDiagram
    participant EB as EventBridge
    participant SL as Sender Lambda
    participant SQS as SQS Queue
    participant CL as Collector Lambda
    participant API as API Gateway
    participant ML as Mock API Lambda
    participant DDB as DynamoDB

    Note over EB: 毎分0秒
    EB->>SL: トリガー実行

    activate SL
    SL->>SL: 基準時刻取得<br/>(例: 10:23:00)

    loop 12回繰り返し (i=0 to 11)
        SL->>SL: 時間幅計算<br/>from: 基準時刻 + i*5秒<br/>to: 基準時刻 + (i+1)*5秒
        SL->>SQS: メッセージ送信<br/>{from, to}<br/>DelaySeconds: i*5
    end

    SL-->>EB: 完了
    deactivate SL

    Note over SQS: 遅延後、5秒ごとにメッセージ配信

    loop 12回 (5秒間隔)
        SQS->>CL: メッセージ配信<br/>{from, to}

        activate CL
        CL->>CL: メッセージパース<br/>from, to取得

        CL->>API: GET /response_count<br/>?from={from}&to={to}

        activate API
        API->>ML: Lambda呼び出し<br/>(プロキシ統合)

        activate ML
        ML->>ML: クエリパラメータ検証
        ML->>ML: ISO8601パース
        ML->>ML: カウント計算<br/>(時刻ベース)
        ML-->>API: 200 OK<br/>{from, to, count}
        deactivate ML

        API-->>CL: JSON レスポンス
        deactivate API

        CL->>CL: レスポンスパース
        CL->>CL: スロットタイム計算<br/>(5秒境界に切り捨て)

        CL->>DDB: PutItem (条件付き)<br/>Condition: attribute_not_exists

        alt 新規レコード
            DDB-->>CL: 成功
        else 既存レコード
            DDB-->>CL: ConditionalCheckFailedException
            Note over CL: 冪等性により無視
        end

        CL->>SQS: メッセージ削除
        CL-->>SQS: 完了
        deactivate CL
    end
```

## 詳細シーケンス: Sender Lambda

```mermaid
sequenceDiagram
    participant EB as EventBridge
    participant SL as Sender Lambda
    participant SQS as SQS Queue

    EB->>SL: スケジュールイベント<br/>{time: "2025-12-03T10:23:00Z"}

    activate SL
    Note over SL: 環境変数読み込み
    SL->>SL: QUEUE_URL取得

    Note over SL: 基準時刻設定
    SL->>SL: baseTime = new Date()<br/>baseTime.setSeconds(0)<br/>baseTime.setMilliseconds(0)

    Note over SL: メッセージ生成ループ
    loop i = 0 to 11
        SL->>SL: fromTime = baseTime + (i * 5秒)<br/>toTime = baseTime + ((i+1) * 5秒)
        SL->>SL: delaySeconds = i * 5

        SL->>SL: メッセージ作成<br/>{<br/>  from: fromTime.toISOString(),<br/>  to: toTime.toISOString()<br/>}

        SL->>SQS: SendMessage<br/>MessageBody: JSON<br/>DelaySeconds: delaySeconds

        alt 送信成功
            SQS-->>SL: MessageId
            Note over SL: ログ出力: 成功
        else 送信失敗
            SQS-->>SL: エラー
            Note over SL: ログ出力: エラー<br/>※続行
        end
    end

    SL-->>EB: 200 OK
    deactivate SL
```

## 詳細シーケンス: Collector Lambda

```mermaid
sequenceDiagram
    participant SQS as SQS Queue
    participant CL as Collector Lambda
    participant API as Mock API
    participant DDB as DynamoDB

    SQS->>CL: SQSEvent<br/>Records[0].body

    activate CL
    Note over CL: 環境変数読み込み
    CL->>CL: AI_API_BASE_URL取得<br/>AI_METRICS_TABLE_NAME取得

    Note over CL: メッセージパース
    CL->>CL: message = JSON.parse(body)<br/>{from, to}

    Note over CL: API呼び出し
    CL->>CL: url = `${baseUrl}/response_count`<br/>+ `?from=${from}&to=${to}`

    CL->>API: fetch(url)

    activate API
    API->>API: クエリパラメータ検証

    alt パラメータ不足
        API-->>CL: 400 Bad Request<br/>{error: "Missing parameters"}
        Note over CL: エラーログ出力<br/>例外スロー
    else パラメータ正常
        API->>API: 日付パース<br/>fromDate = new Date(from)<br/>toDate = new Date(to)

        alt 無効な日付形式
            API-->>CL: 400 Bad Request<br/>{error: "Invalid ISO8601"}
            Note over CL: エラーログ出力<br/>例外スロー
        else 日付正常
            API->>API: カウント計算<br/>hour = toDate.getUTCHours()<br/>minute = toDate.getUTCMinutes()<br/>second = toDate.getUTCSeconds()
            API->>API: baseCount = (9<=hour<=17) ? 50 : 20<br/>variation = (hour*7 + minute*3 + second) % 40<br/>count = min(100, max(0, baseCount + variation - 20))

            API-->>CL: 200 OK<br/>{from, to, count}
        end
    end
    deactivate API

    Note over CL: レスポンス処理
    CL->>CL: response = await res.json()<br/>{from, to, count}

    Note over CL: スロットタイム計算
    CL->>CL: slotTime = calculateSlotTime(from)<br/>※5秒境界に切り捨て

    Note over CL: DynamoDB書き込み
    CL->>CL: item = {<br/>  metricName: "ai_response_count",<br/>  slotTime: slotTime,<br/>  count: count<br/>}

    CL->>DDB: PutItem<br/>ConditionExpression:<br/>"attribute_not_exists(metricName)<br/>AND attribute_not_exists(slotTime)"

    alt 新規レコード
        DDB-->>CL: 成功
        Note over CL: ログ: レコード書き込み成功
    else 既存レコード（重複）
        DDB-->>CL: ConditionalCheckFailedException
        Note over CL: ログ: 重複レコード（冪等性）<br/>※エラーとして扱わない
    else その他のエラー
        DDB-->>CL: エラー
        Note over CL: エラーログ出力<br/>例外スロー
    end

    CL-->>SQS: 処理完了<br/>メッセージ削除
    deactivate CL
```

## エラーハンドリングフロー

```mermaid
sequenceDiagram
    participant CL as Collector Lambda
    participant API as Mock API
    participant DDB as DynamoDB
    participant SQS as SQS Queue

    Note over CL: 正常フロー
    CL->>API: API呼び出し
    API-->>CL: 200 OK
    CL->>DDB: 書き込み
    DDB-->>CL: 成功
    CL->>SQS: メッセージ削除

    Note over CL: エラーケース1: API障害
    CL->>API: API呼び出し
    API-->>CL: タイムアウト/エラー
    Note over CL: 例外スロー
    CL-->>SQS: 処理失敗<br/>メッセージ保持
    Note over SQS: 可視性タイムアウト後<br/>再配信（最大3回）

    Note over CL: エラーケース2: DynamoDB障害
    CL->>API: API呼び出し
    API-->>CL: 200 OK
    CL->>DDB: 書き込み
    DDB-->>CL: スロットリング/エラー
    Note over CL: 例外スロー
    CL-->>SQS: 処理失敗<br/>メッセージ保持
    Note over SQS: 再配信

    Note over CL: エラーケース3: 重複（冪等性）
    CL->>API: API呼び出し
    API-->>CL: 200 OK
    CL->>DDB: 書き込み
    DDB-->>CL: ConditionalCheckFailed
    Note over CL: 正常として処理<br/>（冪等性保証）
    CL->>SQS: メッセージ削除
```

## データフロー詳細

```mermaid
graph LR
    subgraph "入力"
        A[EventBridge<br/>トリガー時刻]
    end

    subgraph "Sender Lambda"
        B[基準時刻<br/>2025-12-03T10:23:00Z]
        C[時間幅生成]
        D[SQSメッセージ]
    end

    subgraph "SQS Queue"
        E[メッセージ1<br/>from: 10:23:00<br/>to: 10:23:05<br/>delay: 0s]
        F[メッセージ2<br/>from: 10:23:05<br/>to: 10:23:10<br/>delay: 5s]
        G[...]
    end

    subgraph "Collector Lambda"
        H[API呼び出し<br/>GET /response_count]
        I[レスポンス<br/>count: 45]
        J[スロットタイム<br/>10:23:00Z]
    end

    subgraph "DynamoDB"
        K[レコード<br/>PK: ai_response_count<br/>SK: 2025-12-03T10:23:00Z<br/>count: 45]
    end

    A --> B
    B --> C
    C --> D
    D --> E
    D --> F
    D --> G
    E --> H
    H --> I
    I --> J
    J --> K

    style A fill:#FF9900
    style K fill:#4B4BFF
```
